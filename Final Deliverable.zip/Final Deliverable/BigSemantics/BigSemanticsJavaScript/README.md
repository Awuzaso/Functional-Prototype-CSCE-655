This repo contains the resources necessary for developing javascript (on the client or server) applications powered by [BigSemantics](https://github.com/ecologylab/BigSemantics). 

For more information check out the [Wiki](https://github.com/ecologylab/BigSemanticsJavaScript/wiki).
