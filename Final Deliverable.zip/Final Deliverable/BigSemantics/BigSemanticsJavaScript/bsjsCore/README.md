Home of key components of BSJS (BigSemanticsJavaScript) used for working with metadata and meta-metadata.
