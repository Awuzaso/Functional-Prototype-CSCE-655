var collectionOfCircles_data = {
   "collection_of_circles":{
      "circles":[
         {
            "radius":"1",
            "center":{
               "x":"2",
               "y":"3"
            }
         },
         {
            "radius":"1",
            "center":{
               "x":"2",
               "y":"4"
            }
         },
         {
            "radius":"1",
            "center":{
               "x":"2",
               "y":"5"
            }
         },
         {
            "radius":"1",
            "center":{
               "x":"2",
               "y":"6"
            }
         },
         {
            "radius":"1",
            "center":{
               "x":"2",
               "y":"7"
            }
         }
      ],
      "yo":"1",
      "simpl.type":"tests.circle.CollectionOfCircles"
   }
};

var collectionOfCircles_app_data = {
   "my_collection":{
      "circles":[
         {
            "radius":1,
            "center":{
               "x":2,
               "y":3
            },
            "color": "blue"
         },
         {
            "radius":1,
            "center":{
               "x":2,
               "y":4
            },
            "color": "blue"
         },
         {
            "radius":1,
            "center":{
               "x":2,
               "y":5
            },
            "color": "blue"
         },
         {
            "radius":1,
            "center":{
               "x":2,
               "y":6
            },
            "color": "blue"
         },
         {
            "radius":1,
            "center":{
               "x":2,
               "y":7
            },
            "color": "blue"
         }
      ],
      "yo":1,
      "angle": 270,
      "simpl.type":"tests.circle.CollectionOfCircles"
   }
};