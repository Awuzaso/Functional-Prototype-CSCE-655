var diamond_data = {
   "class_d":{
      "class_a":{
         "x":"1",
         "y":"2",
         "class_c":{
            "simpl.id":"7905810",
            "u":"55",
            "w":"54"
         }
      },
      "class_b":{
         "x":"1",
         "y":"2",
         "class_c":{
            "simpl.ref":"7905810"
         },
         "class_x":{
            "u":"44",
            "w":"33"
         }
      },
      "simpl.type": "tests.graph.diamond.ClassD"
   }
};