var student_data = {
	"student" : {
		"name" : "nabeel",
		"stu_num" : "12343434",
		"simpl.type": "tests.person.Student"
	}
}; 