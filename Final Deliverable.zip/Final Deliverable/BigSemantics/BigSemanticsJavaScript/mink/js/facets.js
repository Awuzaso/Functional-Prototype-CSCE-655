function Facet(name, value, facet_type, value_type){
	this.name = name;
	this.value = value;
	this.facet_type = facet_type;
	this.value_type = value_type;
}

