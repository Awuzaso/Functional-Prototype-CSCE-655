var GEazy = {

	build: function(nodes)
	{
		var vizDiv = document.createElement('div');
			vizDiv.id = "gEazyViz";
			vizDiv.className = "viz-container";

		// do whatever you want to make the viz and put it in the div

		return vizDiv;
	},


};