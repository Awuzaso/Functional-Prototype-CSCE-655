var OvercomplicatedGraphFlowViz = {

	build: function(nodes)
	{
		var vizDiv = document.createElement('div');
			vizDiv.className = "viz-container";

		// do whatever you want to make the viz and put it in the div

		return vizDiv;
	},

};