This is a playground for experimenting with BSJS

Noting here is even halfway likely to work - if it ever did