var CURATION_AUTHORS = [




];
