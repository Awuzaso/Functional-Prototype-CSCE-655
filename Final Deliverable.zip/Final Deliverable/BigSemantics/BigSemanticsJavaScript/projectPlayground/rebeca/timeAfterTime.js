var TimeAfterTime = {};

TimeAfterTime.createView = function()
{
	var div = document.createElement('div');
	
	return div;
};

TimeAfterTime.groupBy = function(fieldName)
{
	
};

TimeAfterTime.sortBy = function(fieldName)
{
	
};